<h1 align="center"> THE FLASH MULTI DEVICE </h1>
<p align="center">  

***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING +FLASH-MD;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+FRANCE+KING;RELEASED+22.2.2024" alt="Typing SVG" /></a>
  </p>
    <img alt="FLASH-MD" width="700" height="300" src="https://files.catbox.moe/tvo4g6.jpg">
<p align="center">
<p align="center">
<a href="https://github.com/franceking1/Flash-Md"><img title="Author" src="https://img.shields.io/badge/FLASH_MD-black?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/franceking1?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/franceking1?label=Followers&style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/franceking1/Flash-Md?&style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/franceking1/Flash-Md?style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/franceking1/Flash-Md?label=Watching&style=social"></a>
  
***

#### SETUP 

***1.`First STAR 🌟 This Repo ` And Then [`FORK`](https://github.com/franceking1/Flash-Md/fork) It***

***2.`Get Session ID` by [`SCANING QR`](https://the-flash-scanner.onrender.com) Or [`PAIRING CODE`](https://king-france.vercel.app) or [`PAIR CODE 2`](https://the-flash-md-sessions.onrender.com/pair)***

* - Copy The Session ID for it Will be needed during deployment*

***

#### DEPLOY TO HEROKU 
**1. If You Don't Have An Account On Heroku**
    <br>
<p align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

**2. If You Have a Heroku Account**
    <br>
<p align="center"><a href="https://france-king.vercel.app"> <img src="https://img.shields.io/badge/DEPLOY%20NOW-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


***


### DISCLAIMER 🛡 
- Copying or modying this script is not allowed! For we shall not offer any help if any error occur!

***
### HELP :
**IF you need any help**
- [**CLICK HERE**](https://messages-snowy.vercel.app)


***

### THANKS TO:
- [***Fortunatus Mokaya***](https://github.com/Fortunatusmokaya) For several Cmds Addition.
- [***Gifted Tech***](https://github.com/mouricedevs) For Genaral Help and Session Generation
- [***Suhail Ser***](https://github.com/SuhailTechInfo) For Code encryption 
- [***Luffy***](https://github.com/Luffy2ndAccount) For Providing a Base of **FLASH-MD**
